<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RackController;

Route::resource('racks', RackController::class)
    ->middleware('permission:racks.manage');
