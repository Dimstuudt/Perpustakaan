<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RolePermissionSeeder extends Seeder
{
    public function run()
    {
        // Clear cache permission
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        // Buat permission
        $permissions = [
            "users.view",
            "users.create",
            "users.edit",
            "users.delete",
            "users.show",
            "users.toggleStatus",
            "roles.view",
            "roles.create",
            "roles.edit",
            "roles.delete",
            "permissions.view",
            "permissions.create",
            "permissions.edit",
            "permissions.delete",
            "books.create",
            "books.view",
            "books.delete",
            "books.edit",
            "books.restore",
            "books.preview",
            "books.forceDelete",
            "racks.manage",
            "cabinets.manage",
            "categories.view",
            "categories.create",
            "categories.delete",
            "categories.edit",
            "categories.restore",
            "categories.forceDelete",
            "loans.view",
            "loans.user",
            "loans.approve",
            "loans.return",
            "loans.reject",
            "dashboard.view",

        ];
        foreach ($permissions as $permission) {
            Permission::firstOrCreate(['name' => $permission]);
        }

        // Buat role dan assign permission
        $adminRole = Role::firstOrCreate(['name' => 'Super Admin']);
        $adminRole->syncPermissions($permissions);
        $adminRole = Role::firstOrCreate(['name' => 'Admin']);
        $adminRole->syncPermissions(['users.view', 'roles.view', 'users.create', 'users.edit', 'users.delete',]);

        $userRole = Role::firstOrCreate(['name' => 'user']);
        $userRole->givePermissionTo(['']);
    }
}

